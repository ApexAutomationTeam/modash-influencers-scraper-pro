(function () {
  document.getElementById('modash-scraper-ui')?.remove();
  window.__modashScraperActive = true;

  // ══════════════════════════════════════════
  //  ORIGINAL FETCH/XHR — store once
  // ══════════════════════════════════════════
  if (!window.__mdsh_origFetch) window.__mdsh_origFetch = window.fetch;
  if (!window.__mdsh_OrigXHR)   window.__mdsh_OrigXHR   = window.XMLHttpRequest;
  const origFetch = window.__mdsh_origFetch;
  const OrigXHR   = window.__mdsh_OrigXHR;

  // ══════════════════════════════════════════
  //  XLS DOWNLOAD — SpreadsheetML, full col widths
  // ══════════════════════════════════════════
  function dlXLS(data, fname) {
    if (!data?.length) { alert('No data!'); return; }
    function esc(s) {
      return String(s ?? '')
        .replace(/&/g,'&amp;').replace(/</g,'&lt;')
        .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
    }
    const keys = Object.keys(data[0]);
    const colW = {
      'Username':140,'Full Name':190,'Followers':90,
      'Engagement Rate %':130,'Engagements':100,'Email(s)':250,
      'Profile URL':290,'Profile Picture URL':330,'Platform':90,
      'Verified':70,'Private':70,'Hiding Likes':90,
      'Country':130,'Country Code':90,'User ID':140,
      'Profile ID':210,'Last Updated':160
    };
    let xml = `<?xml version="1.0" encoding="UTF-8"?><?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
<Styles>
<Style ss:ID="h"><Font ss:Bold="1" ss:Color="#FFFFFF" ss:Size="10"/><Interior ss:Color="#6366F1" ss:Pattern="Solid"/><Alignment ss:Horizontal="Center" ss:Vertical="Center"/></Style>
<Style ss:ID="d"><Alignment ss:Vertical="Center" ss:WrapText="0"/><Font ss:Size="10"/></Style>
<Style ss:ID="n"><Alignment ss:Vertical="Center"/><Font ss:Size="10"/><NumberFormat ss:Format="General"/></Style>
</Styles>
<Worksheet ss:Name="Influencers"><Table ss:DefaultRowHeight="16">`;
    keys.forEach(k => { xml += `<Column ss:Width="${colW[k]||120}"/>`; });
    xml += '<Row ss:Height="22">';
    keys.forEach(k => { xml += `<Cell ss:StyleID="h"><Data ss:Type="String">${esc(k)}</Data></Cell>`; });
    xml += '</Row>';
    data.forEach(row => {
      xml += '<Row>';
      keys.forEach(k => {
        const v = row[k] ?? '';
        const isN = (k==='Followers'||k==='Engagements') && typeof v==='number';
        xml += `<Cell ss:StyleID="${isN?'n':'d'}"><Data ss:Type="${isN?'Number':'String'}">${esc(String(v))}</Data></Cell>`;
      });
      xml += '</Row>';
    });
    xml += '</Table></Worksheet></Workbook>';
    const blob = new Blob([xml],{type:'application/vnd.ms-excel;charset=utf-8'});
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = fname+'.xls';
    document.body.appendChild(a); a.click();
    setTimeout(()=>{document.body.removeChild(a);URL.revokeObjectURL(a.href);},2000);
    console.log(`[SCRAPER] ✅ ${fname}.xls — ${data.length} rows`);
  }

  // ══════════════════════════════════════════
  //  LOCALSTORAGE
  // ══════════════════════════════════════════
  const LS_S = 'mdsh_sess_v8', LS_P = 'mdsh_prog_v8';
  const loadSess = () => { try { return JSON.parse(localStorage.getItem(LS_S)||'[]'); } catch(e) { return []; } };
  const saveSess = s => { try { localStorage.setItem(LS_S, JSON.stringify(s)); } catch(e) {} };
  const loadProg = () => { try { return JSON.parse(localStorage.getItem(LS_P)||'null'); } catch(e) { return null; } };
  const saveProg = p => { try { localStorage.setItem(LS_P, JSON.stringify(p)); } catch(e) {} };
  const clearProg = () => localStorage.removeItem(LS_P);

  // ══════════════════════════════════════════
  //  STATE
  // ══════════════════════════════════════════
  const prog = loadProg();
  const S = {
    running: false,
    stopRequested: false,
    allData: [],
    sessions: loadSess(),
    capturedReq: prog?.capturedReq || null,
    limit: 50,
    delay: 1200,
    totalPages: prog?.totalPages || 0,
    totalFound: prog?.totalFound  || 0,
    nextPage: prog?.lastPage !== undefined ? prog.lastPage + 1 : 0,
  };

  // ══════════════════════════════════════════
  //  INTERCEPT — ★ ALWAYS update capturedReq
  //  when scraper is NOT running (filter change fix)
  // ══════════════════════════════════════════
  function shouldCapture(url) {
    return url.includes('/api/discovery/search/');
  }

  function captureRequest(req) {
    // Only update when scraper is idle — prevents overwriting mid-scrape
    if (S.running) return;
    S.capturedReq = req;
    // Reset page to 0 when new filters detected
    S.nextPage = 0;
    saveProg({
      lastPage: 0,
      capturedReq: req,
      totalPages: S.totalPages,
      totalFound: S.totalFound
    });
    onCapture(req.url, true);
  }

  function PatchedXHR() {
    const xhr = new OrigXHR();
    let _u='', _m='GET', _h={};
    xhr.open = new Proxy(xhr.open, { apply(t,th,a) { _m=a[0]; _u=a[1]; return t.apply(th,a); } });
    xhr.setRequestHeader = new Proxy(xhr.setRequestHeader, { apply(t,th,a) { _h[a[0]]=a[1]; return t.apply(th,a); } });
    xhr.send = new Proxy(xhr.send, { apply(t,th,a) {
      if (shouldCapture(_u)) {
        captureRequest({ url:_u, method:_m, headers:{..._h}, body:a[0] });
      }
      return t.apply(th,a);
    }});
    return xhr;
  }
  PatchedXHR.prototype = OrigXHR.prototype;
  window.XMLHttpRequest = PatchedXHR;

  window.fetch = async function(...args) {
    const url  = typeof args[0]==='string' ? args[0] : (args[0]?.url||'');
    const opts = args[1] || {};
    if (shouldCapture(url)) {
      captureRequest({ url, method:opts.method||'POST', headers:opts.headers||{}, body:opts.body||null });
    }
    return origFetch.apply(this, args);
  };

  function onCapture(url, isNew=false) {
    console.log(`%c[SCRAPER] ${isNew?'🔄 NEW':'✅'} Request captured: ${url}`, 'color:lime;font-weight:bold');
    const btn = document.getElementById('ms-start-btn');
    const ac  = document.getElementById('ms-autocon');
    if (btn) { btn.disabled=false; btn.style.opacity='1'; }
    if (ac)  { ac.textContent='✅ Connected'; ac.style.background='#065f46'; ac.disabled=true; }
    updateBadge();
    setStatus(
      isNew
        ? `🔄 <b>Naye filters capture ho gaye!</b><br>📍 Page <b>1</b> se fresh start hoga`
        : `✅ <b>Request captured!</b><br>📍 Page <b>${S.nextPage+1}</b> se start hoga`,
      'g'
    );
  }

  // ══════════════════════════════════════════
  //  UI
  // ══════════════════════════════════════════
  const ui = document.createElement('div');
  ui.id = 'modash-scraper-ui';
  ui.innerHTML = `
<style>
#modash-scraper-ui *{box-sizing:border-box;font-family:'Segoe UI',system-ui,sans-serif;}
#modash-scraper-ui{
  position:fixed;top:12px;right:12px;z-index:2147483647;width:395px;
  background:#0a0a14;border:1.5px solid #6366f1;border-radius:16px;
  box-shadow:0 16px 50px rgba(99,102,241,.6);color:#e2e8f0;
}
#ms-head{
  background:linear-gradient(135deg,#6366f1,#8b5cf6);
  padding:13px 16px;border-radius:16px 16px 0 0;
  display:flex;justify-content:space-between;align-items:center;cursor:move;
}
#ms-head h3{margin:0;font-size:14px;font-weight:800;color:#fff;}
#ms-ver{background:rgba(255,255,255,.2);padding:3px 10px;border-radius:20px;font-size:10px;color:#e0d9ff;}
#ms-body{padding:14px 15px;}

/* PAGE MEMORY BANNER */
#ms-mem{
  display:flex;justify-content:space-between;align-items:center;
  background:#0c1f0c;border:1px solid #166534;border-radius:9px;
  padding:8px 12px;margin-bottom:10px;
}
#ms-mem-txt{font-size:11px;color:#86efac;line-height:1.65;}
#ms-mem-btns{display:flex;gap:5px;flex-shrink:0;}
.mbtn{
  background:transparent;border:1px solid #166534;color:#86efac;
  padding:3px 9px;border-radius:5px;font-size:10px;cursor:pointer;font-weight:600;
}
.mbtn.red{border-color:#7f1d1d;color:#fca5a5;}
.mbtn.blue{border-color:#1e40af;color:#93c5fd;}
.mbtn:hover{opacity:.75;}

/* STATUS BOX */
.ms-sb{
  padding:10px 13px;border-radius:9px;font-size:11.5px;line-height:1.7;
  margin-bottom:10px;border-left:3px solid #6366f1;background:#11112a;min-height:52px;
}
.ms-sb.g{border-color:#10b981;}
.ms-sb.o{border-color:#f59e0b;}
.ms-sb.r{border-color:#ef4444;}
.ms-sb.b{border-color:#3b82f6;}

/* PROGRESS */
#ms-pbar{width:100%;height:6px;background:#1a1a35;border-radius:3px;overflow:hidden;margin-bottom:11px;}
#ms-pfill{height:100%;width:0%;background:linear-gradient(90deg,#6366f1,#a78bfa);transition:width .4s;border-radius:3px;}

/* CONTROLS */
.ms-row{display:flex;gap:7px;margin-bottom:9px;align-items:center;}
.ms-lbl{font-size:10.5px;color:#94a3b8;min-width:50px;}
.ms-sel{
  flex:1;background:#14142a;border:1px solid #2d2d50;color:#e2e8f0;
  padding:6px 8px;border-radius:7px;font-size:11.5px;cursor:pointer;
}
.ms-btn{
  flex:1;padding:9px 6px;border:none;border-radius:8px;
  font-size:11.5px;font-weight:700;cursor:pointer;
  transition:opacity .15s,transform .1s;letter-spacing:.2px;
}
.ms-btn:active{transform:scale(.97);}
.ms-btn:disabled{opacity:.3!important;cursor:not-allowed!important;}
#ms-autocon{
  width:100%;padding:9px;background:#0ea5e9;color:#fff;border:none;
  border-radius:8px;font-size:12px;font-weight:700;cursor:pointer;margin-bottom:9px;
}
#ms-recapture{
  width:100%;padding:8px;background:#7c3aed;color:#fff;border:none;
  border-radius:8px;font-size:11.5px;font-weight:700;cursor:pointer;margin-bottom:9px;
}
#ms-start-btn{background:#6366f1;color:#fff;}
#ms-stop-btn{background:#dc2626;color:#fff;}

/* SESSION LIST */
.ms-div{border:none;border-top:1px solid #1a1a35;margin:10px 0;}
#ms-sw{
  background:#0d0d22;border:1px solid #1e2040;border-radius:9px;
  margin-bottom:10px;max-height:200px;overflow-y:auto;
}
#ms-sh{
  padding:8px 12px;font-size:10.5px;color:#94a3b8;
  border-bottom:1px solid #1e2040;
  display:flex;justify-content:space-between;align-items:center;
  position:sticky;top:0;background:#0d0d22;z-index:1;
}
#ms-sl{padding:4px 0;}
.si{display:flex;align-items:center;padding:7px 12px;border-bottom:1px solid #111128;gap:9px;}
.si:last-child{border-bottom:none;}
.si:hover{background:#13132a;}
.scb{width:15px;height:15px;accent-color:#6366f1;cursor:pointer;flex-shrink:0;}
.sin{flex:1;font-size:11px;}
.sin .sn{font-weight:600;color:#c4b5fd;}
.sin .sm{color:#64748b;font-size:10px;margin-top:1px;}
.sdl{
  background:transparent;border:1px solid #374151;color:#94a3b8;
  padding:4px 9px;border-radius:5px;font-size:10px;cursor:pointer;
}
.sdl:hover{background:#1e2040;color:#e2e8f0;}
.sde{background:transparent;border:none;color:#4b5563;font-size:15px;cursor:pointer;padding:0 2px;}
.sde:hover{color:#ef4444;}
#ms-ca{background:transparent;border:none;color:#4b5563;font-size:10px;cursor:pointer;text-decoration:underline;}
#ms-ca:hover{color:#ef4444;}
#ms-cb-btn{
  width:100%;padding:10px;border:none;border-radius:9px;
  background:linear-gradient(135deg,#d97706,#b45309);
  color:#fff;font-size:12px;font-weight:800;cursor:pointer;
}
#ms-cb-btn:disabled{opacity:.3;cursor:not-allowed;}
</style>

<div id="ms-head">
  <h3>🚀 Modash Scraper</h3>
  <span id="ms-ver">FINAL v8 ✓</span>
</div>
<div id="ms-body">

  <!-- PAGE MEMORY -->
  <div id="ms-mem">
    <div id="ms-mem-txt">
      📍 Next: Page <b id="ms-np">1</b> &nbsp;|&nbsp; Done: <b id="ms-pd">0</b> pages<br>
      <span style="font-size:10px;color:#4ade80">Total rows saved: <b id="ms-rd">0</b></span>
    </div>
    <div id="ms-mem-btns">
      <button class="mbtn blue" id="ms-set-btn">✎ Set</button>
      <button class="mbtn red"  id="ms-rst-btn">↺ Reset</button>
    </div>
  </div>

  <div id="ms-sb" class="ms-sb">
    💡 Modash pe koi filter/sort click karo → auto-capture<br>
    Ya <b>Auto-Connect</b> try karo
  </div>
  <div id="ms-pbar"><div id="ms-pfill"></div></div>

  <!-- FILTER CHANGE BUTTON -->
  <button id="ms-recapture">🔄 Filters Change Kiye? Yahan Click Karo → Re-Capture</button>
  <button id="ms-autocon">⚡ Auto-Connect (Direct API Try)</button>

  <div class="ms-row">
    <span class="ms-lbl">Limit</span>
    <select class="ms-sel" id="ms-limit">
      <option value="10">10</option>
      <option value="20">20</option>
      <option value="30">30</option>
      <option value="40">40</option>
      <option value="50" selected>50</option>
      <option value="100">100</option>
      <option value="150">150</option>
      <option value="300">300</option>
      <option value="500">500</option>
      <option value="1000">1,000</option>
      <option value="3000">3,000</option>
      <option value="5000">5,000</option>
      <option value="9999999">ALL</option>
    </select>
    <span class="ms-lbl" style="margin-left:4px">Delay</span>
    <select class="ms-sel" id="ms-delay">
      <option value="700">Fast (700ms)</option>
      <option value="1200" selected>Normal (1.2s)</option>
      <option value="2000">Safe (2s)</option>
      <option value="3500">Slow (3.5s)</option>
    </select>
  </div>

  <div class="ms-row">
    <button class="ms-btn" id="ms-start-btn" disabled>▶ Start</button>
    <button class="ms-btn" id="ms-stop-btn"  disabled>⏹ Stop & Save</button>
  </div>

  <hr class="ms-div">

  <div id="ms-sw">
    <div id="ms-sh">
      <span id="ms-sc">📁 Sessions (0)</span>
      <button id="ms-ca">🗑 Clear All</button>
    </div>
    <div id="ms-sl">
      <div style="padding:14px;text-align:center;color:#4b5563;font-size:11px;">No sessions yet</div>
    </div>
  </div>

  <button id="ms-cb-btn" disabled>🔗 Combine Selected → XLS</button>

</div>`;
  document.body.appendChild(ui);

  // Drag
  let drag=false,dx=0,dy=0;
  document.getElementById('ms-head').onmousedown = e=>{drag=true;dx=e.clientX-ui.offsetLeft;dy=e.clientY-ui.offsetTop;};
  document.addEventListener('mousemove', e=>{if(!drag)return;ui.style.left=(e.clientX-dx)+'px';ui.style.top=(e.clientY-dy)+'px';ui.style.right='auto';});
  document.addEventListener('mouseup', ()=>drag=false);

  // ══════════════════════════════════════════
  //  UI HELPERS
  // ══════════════════════════════════════════
  function setStatus(html, cls='') {
    const el = document.getElementById('ms-sb');
    el.innerHTML = html;
    el.className = 'ms-sb' + (cls ? ' '+cls : '');
  }
  function setProgress(done, total) {
    const pct = total>0 ? Math.min(100, Math.round(done/Math.min(total,S.limit)*100)) : 0;
    document.getElementById('ms-pfill').style.width = pct+'%';
  }
  function updateBadge() {
    document.getElementById('ms-np').textContent = S.nextPage + 1;
    document.getElementById('ms-pd').textContent = S.nextPage;
    const rows = S.sessions.reduce((a,s)=>a+s.count, 0);
    document.getElementById('ms-rd').textContent = rows.toLocaleString();
  }
  function renderSessions() {
    const sl = document.getElementById('ms-sl');
    document.getElementById('ms-sc').textContent = `📁 Sessions (${S.sessions.length})`;
    if (!S.sessions.length) {
      sl.innerHTML = '<div style="padding:14px;text-align:center;color:#4b5563;font-size:11px;">No sessions yet</div>';
      document.getElementById('ms-cb-btn').disabled = true;
      return;
    }
    sl.innerHTML = S.sessions.map((s,i) => `
      <div class="si">
        <input type="checkbox" class="scb" data-i="${i}" checked>
        <div class="sin">
          <div class="sn">Session ${s.id} <span style="font-size:9px;color:#4b5563">pg${s.sp+1}→pg${s.ep+1}</span></div>
          <div class="sm">${s.count} rows &nbsp;·&nbsp; ${new Date(s.ts).toLocaleString()}</div>
        </div>
        <button class="sdl" data-i="${i}">⬇ DL</button>
        <button class="sde" data-i="${i}">✕</button>
      </div>`).join('');

    sl.querySelectorAll('.sdl').forEach(b => b.onclick = () => {
      const s = S.sessions[+b.dataset.i];
      if (s) dlXLS(s.data, `modash_s${s.id}_pg${s.sp+1}-pg${s.ep+1}_${s.count}rows`);
    });
    sl.querySelectorAll('.sde').forEach(b => b.onclick = () => {
      S.sessions.splice(+b.dataset.i, 1);
      saveSess(S.sessions); renderSessions(); updateBadge();
    });
    document.getElementById('ms-cb-btn').disabled = false;
  }

  // ══════════════════════════════════════════
  //  EXTRACT ROW — all columns
  // ══════════════════════════════════════════
  function extract(item) {
    const p   = item.profileData?.profile || {};
    const geo = item.profileData?.match?.user_profile?.geo?.country || {};
    return {
      'Username':            p.username  || '',
      'Full Name':           p.fullname  || '',
      'Followers':           p.followers || 0,
      'Engagement Rate %':   p.engagementRate ? (p.engagementRate*100).toFixed(4) : '0',
      'Engagements':         p.engagements || 0,
      'Email(s)':            (item.emails||[]).join(', '),
      'Profile URL':         p.url || `https://www.instagram.com/${p.username}`,
      'Profile Picture URL': p.picture || '',
      'Platform':            item.profileType || 'INSTAGRAM',
      'Verified':            p.isVerified   ? 'Yes' : 'No',
      'Private':             p.isPrivate    ? 'Yes' : 'No',
      'Hiding Likes':        p.isHidingLikes? 'Yes' : 'No',
      'Country':             geo.name || '',
      'Country Code':        geo.code || '',
      'User ID':             item.profileData?.userId || '',
      'Profile ID':          item.profileId || '',
      'Last Updated':        item.profileData?.updatedAt || '',
    };
  }

  // ══════════════════════════════════════════
  //  FETCH ONE PAGE
  // ══════════════════════════════════════════
  async function fetchPage(page) {
    let body = S.capturedReq.body;
    try {
      const p = JSON.parse(body);
      p.page = page;
      body = JSON.stringify(p);
    } catch(e) {
      body = JSON.stringify({ page });
    }
    const res = await origFetch(S.capturedReq.url, {
      method:  S.capturedReq.method || 'POST',
      headers: { 'Content-Type':'application/json', ...(S.capturedReq.headers||{}) },
      credentials: 'include',
      body,
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return res.json();
  }

  // ══════════════════════════════════════════
  //  SCRAPE LOOP — fixed pagination
  // ══════════════════════════════════════════
  async function startScraping() {
    if (!S.capturedReq) { setStatus('❌ Pehle request capture karo!','r'); return; }
    S.running      = true;
    S.stopRequested = false;
    S.allData      = [];
    S.limit  = +document.getElementById('ms-limit').value;
    S.delay  = +document.getElementById('ms-delay').value;

    document.getElementById('ms-start-btn').disabled = true;
    document.getElementById('ms-stop-btn').disabled  = false;
    document.getElementById('ms-stop-btn').style.opacity = '1';
    document.getElementById('ms-recapture').disabled = true;
    document.getElementById('ms-autocon').disabled   = true;

    const startPage = S.nextPage;
    let page = startPage, fetched = 0, errors = 0;

    setStatus(`▶ Page <b>${startPage+1}</b> se start<br>🎯 Target: <b>${S.limit===9999999?'ALL':S.limit}</b> influencers`, 'b');

    while (!S.stopRequested && fetched < S.limit) {
      try {
        setStatus(
          `📡 Page <b>${page+1}</b>/${S.totalPages||'?'} &nbsp;·&nbsp; ✅ <b>${fetched}</b> / ${S.limit===9999999?(S.totalFound||'?').toLocaleString():S.limit}<br>` +
          `🔖 Start: pg${startPage+1} &nbsp;·&nbsp; ⏱ ${new Date().toLocaleTimeString()}`
        );

        const json  = await fetchPage(page);
        const items = json.lookalikes || [];

        if (json.total) S.totalFound = json.total;
        if (json.pages) S.totalPages = json.pages;

        if (!items.length) {
          setStatus(`✅ <b>Koi aur data nahi!</b> Collected: <b>${fetched}</b>`,'g');
          break;
        }

        for (const it of items) {
          if (fetched >= S.limit) break;
          S.allData.push(extract(it));
          fetched++;
        }

        setProgress(fetched, S.totalFound);
        errors = 0;

        // Save progress after every page
        S.nextPage = page + 1;
        saveProg({ lastPage:page, capturedReq:S.capturedReq, totalPages:S.totalPages, totalFound:S.totalFound });
        updateBadge();

        // Stop conditions (FIXED — no page+1>=pages check)
        if (fetched >= S.limit) break;
        if (!json.nextPageEnabled) {
          setStatus(`✅ <b>Sab pages khatam!</b> Collected: <b>${fetched}</b>`,'g');
          break;
        }

        page++;
        await sleep(S.delay);

      } catch(err) {
        errors++;
        setStatus(`⚠️ Error pg${page+1}: ${err.message} &nbsp; retry ${errors}/3`,'r');
        if (errors >= 3) { setStatus('❌ 3 consecutive errors — stopping.','r'); break; }
        await sleep(3000);
      }
    }

    S.running = false;
    document.getElementById('ms-recapture').disabled = false;
    document.getElementById('ms-autocon').disabled   = false;
    endSession(startPage, page);
  }

  function endSession(sp, ep) {
    document.getElementById('ms-start-btn').disabled = false;
    document.getElementById('ms-start-btn').style.opacity = '1';
    document.getElementById('ms-stop-btn').disabled  = true;
    document.getElementById('ms-stop-btn').style.opacity = '.3';

    if (!S.allData.length) { setStatus('⚠️ Koi data nahi mila.','o'); return; }

    const n    = S.sessions.length ? Math.max(...S.sessions.map(s=>s.id))+1 : 1;
    const sess = { id:n, count:S.allData.length, ts:Date.now(), sp, ep, data:[...S.allData] };
    S.sessions.push(sess);
    saveSess(S.sessions);
    renderSessions();
    updateBadge();

    setStatus(`🎉 <b>Session ${n} done!</b> pg${sp+1}→pg${ep+1}<br>📊 <b>${S.allData.length}</b> rows → downloading...`,'g');
    dlXLS(S.allData, `modash_s${n}_pg${sp+1}-pg${ep+1}_${S.allData.length}rows`);
    setProgress(S.allData.length, S.allData.length);
  }

  // ══════════════════════════════════════════
  //  AUTO CONNECT
  // ══════════════════════════════════════════
  async function autoConnect() {
    document.getElementById('ms-autocon').disabled = true;
    document.getElementById('ms-autocon').textContent = '⏳ Connecting...';
    setStatus('⚡ Direct API call try ho rahi hai...','b');
    try {
      const res = await origFetch('https://marketer.modash.io/api/discovery/search/instagram', {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type':'application/json' },
        body: JSON.stringify({ page: S.nextPage }),
      });
      if (res.ok) {
        const json = await res.json();
        if (json.lookalikes?.length) {
          S.capturedReq = {
            url:    'https://marketer.modash.io/api/discovery/search/instagram',
            method: 'POST',
            headers:{ 'Content-Type':'application/json' },
            body:   JSON.stringify({ page: S.nextPage }),
          };
          S.totalPages = json.pages || 0;
          S.totalFound = json.total || 0;
          onCapture(S.capturedReq.url, false);
          setStatus(
            `✅ <b>Auto-Connect kamyab!</b><br>` +
            `📊 Total: <b>${(json.total||0).toLocaleString()}</b> &nbsp;·&nbsp; Pages: <b>${json.pages||0}</b><br>` +
            `📍 Page <b>${S.nextPage+1}</b> se start hoga`,'g'
          );
          return;
        }
      }
    } catch(e) {}
    setStatus('⚠️ Auto-Connect fail hua.<br>Modash pe koi filter ya sort click karo → auto-capture.','o');
    document.getElementById('ms-autocon').disabled = false;
    document.getElementById('ms-autocon').textContent = '⚡ Retry Auto-Connect';
  }

  const sleep = ms => new Promise(r => setTimeout(r, ms));

  // ══════════════════════════════════════════
  //  BUTTONS
  // ══════════════════════════════════════════
  document.getElementById('ms-autocon').onclick   = autoConnect;
  document.getElementById('ms-start-btn').onclick = startScraping;
  document.getElementById('ms-stop-btn').onclick  = () => {
    S.stopRequested = true;
    setStatus('⏹ Ruk raha hai... page complete ke baad save hoga.','o');
  };

  // ★ RE-CAPTURE BUTTON — filter change ke baad
  document.getElementById('ms-recapture').onclick = () => {
    S.capturedReq = null;
    S.nextPage    = 0;
    clearProg();
    updateBadge();
    document.getElementById('ms-start-btn').disabled = true;
    document.getElementById('ms-start-btn').style.opacity = '.3';
    document.getElementById('ms-autocon').disabled  = false;
    document.getElementById('ms-autocon').textContent = '⚡ Auto-Connect (Direct API Try)';
    document.getElementById('ms-autocon').style.background = '#0ea5e9';
    setStatus('🔄 <b>Re-Capture mode ON!</b><br>Ab Modash pe apna filter apply karo ya sort click karo → naya request capture hoga','o');
    console.log('[SCRAPER] Re-capture mode ON — waiting for new filter request...');
  };

  document.getElementById('ms-cb-btn').onclick = () => {
    const checked = [...document.querySelectorAll('.scb:checked')].map(cb => +cb.dataset.i);
    if (!checked.length) { setStatus('❌ Koi session select nahi kiya!','r'); return; }
    const all = checked.flatMap(i => S.sessions[i]?.data || []);
    const seen = new Set();
    const deduped = all.filter(r => {
      const k = r['Username']+'|'+r['User ID'];
      return seen.has(k) ? false : (seen.add(k), true);
    });
    setStatus(`🔗 <b>${checked.length}</b> sessions combine ho rahe hain...<br>📊 <b>${deduped.length}</b> unique rows → downloading...`,'b');
    dlXLS(deduped, `modash_COMBINED_${checked.length}sess_${deduped.length}rows`);
  };

  document.getElementById('ms-ca').onclick = () => {
    if (confirm(`Sab ${S.sessions.length} sessions delete karo? (Downloaded XLS files safe rahenge)`)) {
      S.sessions = []; saveSess([]); renderSessions(); updateBadge();
    }
  };

  document.getElementById('ms-rst-btn').onclick = () => {
    if (confirm('Page counter reset karo? Agla session Page 1 se shuru hoga.')) {
      clearProg(); S.nextPage = 0; updateBadge();
      setStatus('↺ <b>Reset ho gaya!</b> Agla session Page 1 se.','o');
    }
  };

  document.getElementById('ms-set-btn').onclick = () => {
    const p = prompt(`Konse page se start karo?\n(Abhi: Page ${S.nextPage+1})`, S.nextPage+1);
    if (p === null || p === '') return;
    const num = parseInt(p);
    if (isNaN(num) || num < 1) { alert('1 ya usse bada number dalo!'); return; }
    S.nextPage = num - 1;
    saveProg({ lastPage: Math.max(0,num-2), capturedReq:S.capturedReq, totalPages:S.totalPages, totalFound:S.totalFound });
    updateBadge();
    setStatus(`✏️ Page <b>${num}</b> se set ho gaya. Start dabao!`,'g');
  };

  // ══════════════════════════════════════════
  //  INIT
  // ══════════════════════════════════════════
  renderSessions();
  updateBadge();

  if (S.capturedReq) {
    document.getElementById('ms-start-btn').disabled = false;
    document.getElementById('ms-start-btn').style.opacity = '1';
    document.getElementById('ms-autocon').textContent  = '✅ Connected (Restored)';
    document.getElementById('ms-autocon').style.background = '#065f46';
    document.getElementById('ms-autocon').disabled = true;
    setStatus(`♻️ <b>Previous session restore ho gayi!</b><br>📍 Page <b>${S.nextPage+1}</b> se continue &nbsp;|&nbsp; Filters change kiye? → Purple button dabao`,'g');
  } else if (S.sessions.length) {
    setStatus(`📂 <b>${S.sessions.length} old sessions</b> mili hain!<br>Request capture karo phir continue karo.`,'b');
  }

  console.log('%c[MODASH SCRAPER v8 FINAL] ✅ Ready! Page='+(S.nextPage+1), 'color:lime;font-size:14px;font-weight:bold');
})();
